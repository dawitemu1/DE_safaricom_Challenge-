package com.thinkconstructive.Restdemo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestDemo2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
