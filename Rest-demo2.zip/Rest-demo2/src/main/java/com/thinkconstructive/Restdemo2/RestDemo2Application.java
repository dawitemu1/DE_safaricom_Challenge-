package com.thinkconstructive.Restdemo2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestDemo2Application {

	public static void main(String[] args) {
		SpringApplication.run(RestDemo2Application.class, args);
	}

}
