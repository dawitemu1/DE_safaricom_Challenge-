package com.thinkconstructive.Restdemo2.model;

public class Emp_Attributes {
    private String Id;
    private String Name;
    private String title;
    private  String Dept;

    public Emp_Attributes() {
    }

    public Emp_Attributes(String Id, String Name, String title, String Dept) {
        this.Id = Id;
        this.Name = Name;
        this.title = title;
        this.Dept = Dept;
    }
    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name)
    {
        Name = name;
    }
    public String getTitle()
    {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getDept() {
        return Dept;
    }
    public void setDept(String dept)
    {
        this.Dept = dept;
    }
}
