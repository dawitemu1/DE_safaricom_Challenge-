package com.thinkconstructive.Restdemo2.controller;
import com.thinkconstructive.Restdemo2.model.Emp_Attributes;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cloudvendor")
public class EmployeeAPIService
{
    Emp_Attributes cloudVendor;
    @GetMapping("{Id}")
    public Emp_Attributes getEmp_AttributesDetails(String Id)
    {
        return cloudVendor;
  //        new CloudVendor("EMP123","Yordi",
 //                 "HR manager", "HR");
    }
    @PostMapping
public  String CreateEmp_AttributesDetails(@RequestBody Emp_Attributes cloudVendor)
{
    this.cloudVendor=cloudVendor;
    return "Employee record is created suceessfully";
}
@PutMapping
public  String updateEmp_AttributesDetails(@RequestBody Emp_Attributes cloudVendor)
    {
        this.cloudVendor=cloudVendor;
        return "Employee record is updated suceessfully";
    }

@DeleteMapping("Id")
public  String deleteEmp_AttributesDetails(String Id)
    {
        this.cloudVendor=null;
        return "Employee record is delete suceessfully";
    }
}
