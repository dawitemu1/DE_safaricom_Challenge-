package com.thinkconstructive.Restdemo2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Employee_mgt {

	public static void main(String[] args)
	{ SpringApplication.run(Employee_mgt.class, args);
	}

}
