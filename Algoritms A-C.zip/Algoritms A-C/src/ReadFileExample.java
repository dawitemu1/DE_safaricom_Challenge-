import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.io.IOException;
import java.util.List;

public class ReadFileExample {

    public static void main(String[] args) {
        // Specify the path to the file
        String filePath = "C:/Users/Dawit Shibabaw/Desktop/dave.txt";

        // Read the file and handle IOException
        try {
            // Create a Path object from the file path
            Path path = Paths.get(filePath);

            // Read all lines from the file into a List of Strings
            List<String> lines = Files.readAllLines(path);

            // Print the contents of the file
            for (String line : lines) {
                System.out.println(line);
            }
        } catch (IOException e) {
            // Handle the exception, for example, print an error message
            System.err.println("An error occurred while reading the file: " + e.getMessage());
        }
    }
}
