public class Sumdigits {
    public static void main(String[] args) {
        int number = 163;

        // Convert the number to a string to iterate over its digits
        String numberStr = Integer.toString(number);

        // Initialize the sum
        int sum = 0;

        // Iterate over each character in the string and convert it back to an integer
        for (int i = 0; i < numberStr.length(); i++) {
            char digitChar = numberStr.charAt(i);
            int digit = Character.getNumericValue(digitChar);

            // Add the digit to the sum
            sum += digit;
        }

        // Print the result
        System.out.println("The sum of the digits of " + number + " is: " + sum);
    }
}
