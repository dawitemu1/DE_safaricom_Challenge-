public class BigONotationExample {

    // Example function with O(n) time complexity
    public static void linearTimeComplexity(int[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i]);
        }
    }

    // Example function with O(n^2) time complexity
    public static void quadraticTimeComplexity(int[] array) {
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array.length; j++) {
                System.out.println(array[i] + ", " + array[j]);
            }
        }
    }

    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5};

        // Call the function with linear time complexity
        linearTimeComplexity(array);

        // Call the function with quadratic time complexity
        quadraticTimeComplexity(array);
    }
}
